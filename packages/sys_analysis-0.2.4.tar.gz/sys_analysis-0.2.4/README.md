# Documentation

## PURO

`class PUROMethod(factors, *args)`

___

factors - the expert's possible answers

args - the expert's answers.

___

The class builds matrices for ranking expert answers. There are two method methods how to do this:
1. matching_method(coeff=None)
2. disagreement_method(coeff=None)

where **coeff** is a thresholds.

The methods return a dictionary
**matching method** keys:
- p_matrix
- pz_matrix

**disagreement method** keys:
- canonical_matrixes
- d_matrix
- full_d_matrix
- dz_matrix

More about the method in **"KalugyanHubaev_tsisa.pdf"** file on page 15.

___

## Functional Completeness

`class FunctionalCompleteness(source_matrix)`

___

source_matrix - representation of source matrix. Must be a list or set.

___

The class build matrices for search better product (it can be any product). There is method **calculate**. Parameters:
- e_p - threshold value for P0 matrix
- e_s - threshold value for S0 matrix
- e_h - threshold value for H0 matrix
- e_g - threshold value for G0 matrix

The method return a dictionary with the keys:
- P01
- P10
- P11
- SMatrix
- HMatrix
- GMatrix
- P0Matrix
- S0Matrix
- H0Matrix
- G0Matrix
- full_absorption_matrix

More about the method in **"Functional_Completeness.doc"** file.
