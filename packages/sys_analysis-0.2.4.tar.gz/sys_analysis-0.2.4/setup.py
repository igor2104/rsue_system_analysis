import os
from setuptools import find_packages, setup

with open(os.path.join(os.path.dirname(__file__), 'README.md')) as readme:
    README = readme.read()

# allow setup.py to be run from any path
os.chdir(os.path.normpath(os.path.join(os.path.abspath(__file__), os.pardir)))


setup(
    name='sys_analysis',
    version='0.2.4',
    description="Hubaev's methods of system analysis",
    long_description=README,
    classifiers=[
        'Operating System :: OS Independent',
        'Programming Language :: Python :: 3.6',
    ],
    keywords='system analysis',
    url='https://github.com/poliev/sys_analysis',
    author='Poliev Alexey',
    author_email='poliev80696@gmail.com',
    license='MIT',
    packages=find_packages(),
    install_requires=[ 'numpy==1.15.2', ],
    include_package_data=True,
    zip_safe=False
)
